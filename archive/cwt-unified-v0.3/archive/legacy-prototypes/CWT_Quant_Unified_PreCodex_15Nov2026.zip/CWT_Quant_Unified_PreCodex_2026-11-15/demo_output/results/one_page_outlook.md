# AAPL | Research sentiment outlook

**Evidence classification:** EXPERIMENTAL.

**Last observable session:** 2026-10-13 (as-of close 2026-10-13 20:00:00+00:00).

**n+0:** 93.8396, **observed**, not predicted. Direct n+1..n+5 forecast comparisons: `latest_forecasts.csv`.

**Recent X sentiment:** 20-session unweighted mean -0.025 on a -1 to +1 scale; 267 relevant mapped posts in analysis window. A zero-post session is recorded as zero sentiment and separately flagged.

**Influence availability:** NOT ELIGIBLE; historical engagement snapshots missing or incomplete, influence model withheld.

**Walk-forward testing:** Compare no-change, price-only and price+sentiment for each horizon, with label-release purging and train-only scaling. See `forecast_metrics.csv`; no performance claims are made without independent real-data provenance review.

**Interpretation:** This is a research pipeline. Correlation, forecast skill, and tradeability are distinct claims. The lexical baseline misreads sarcasm, negation, news quotations, and ambiguity; optional externally pre-scored sentiment requires separate validation. News retrieved after an origin must not be used to explain a past prediction as though known then.
