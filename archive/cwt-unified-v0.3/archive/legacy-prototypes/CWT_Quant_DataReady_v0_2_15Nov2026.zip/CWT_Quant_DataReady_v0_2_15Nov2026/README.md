# CrowdWisdomTrading X-Sentiment Research | UNIFIED PRE-CODEX v0.1

**STATUS: EXPERIMENTAL / RESEARCH ONLY.** Built 15 November 2026, from direct inspection of earlier provisional CWT archives and the proposed Influence-Adjusted Market Sentiment Model. This is *not* a verified employer submission, a real forecasting win, or a live X retrieval system.

## What exists
- Input schema contracts and strict XNYS session calendars (holidays, DST and early closes).
- `$AAPL` cashtag precision filter, stable-post deduplication and repeated-author cap.
- Financial-word lexical sentiment baseline or user-supplied signed scores.
- Optional `0.6 post + 0.4 reply` scoring with dated reply snapshots; optional `1 + 0.3 reach + 0.2 engagement`, capped at 1.5x, only on historical as-of engagement snapshots, with at least 50 relevant posts across 20 sessions.
- Direct h=1..5 log-return forecast: unchanged-price, price-only Ridge, price+text Ridge, and optional historical-snapshot influence Ridge.
- Expanding walk-forward daily retraining with per-horizon training-label release checks and train-only standardization.
- Daily sentiment+price PNG, per-horizon model comparison CSV, one-page outline, audit hashes, and idealized next-open-to-next-close research diagnostic when open prices exist.
- Synthetic-data `demo` and regression tests. NO network connection, broker adapter, automated live execution, or third-party model-weight redistribution.

## Install

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e '.[test]'
pytest -q
python -m cwt_unified.cli demo --out demo_output
```

## Run on private, legitimate data

```bash
python -m cwt_unified.cli run --prices raw_data/prices.csv --posts raw_data/posts.csv --ticker AAPL --out results
```

Add `--allow-influence` **ONLY** after historical snapshots and reply collection are confirmed. Without complete eligible timestamps, the influence variant is suppressed and the audit manifest explains why.

### Prices CSV
`date,close` required; `open` strongly recommended for executable research diagnostic. Date is exchange-local session date YYYY-MM-DD; OHLC must reflect one consistent documented corporate action adjustment policy. Dates must cover *every scheduled XNYS session* in the input range; missing sessions hard fail. Derived `market_open_utc` and `market_close_utc` come from `exchange_calendars`. Forecasted prices are in the same units as provided `close` and cannot be casually labeled a live executable market-price forecast if the provider supplied adjusted historical units.

### Posts CSV
Required `timestamp_utc,text`. Recommended `post_id,author_id`, and original source IDs. *Asset relevance currently uses exact `$AAPL` cashtag.* Optional `sentiment` in [-1,+1], `reply_sentiment` in [-1,+1], `reply_asof_utc`; plus `likes,reposts,comments,followers,engagement_asof_utc`. **Do not populate `engagement_asof_utc` with retrieval time** when posts were retrieved after the historical session; that is not a historical snapshot. No score or celebrity heuristic is authoritative by default. The post text may have been edited; independently assess retrospective validity.

## Outputs
- `forecast_metrics.csv`: compare matching test origins and five horizons, but not an alpha claim.
- `walkforward_predictions.csv`: forecast origin and label cutoff for leakage review.
- `latest_forecasts.csv`: n+0 observed value; h1..h5 predicted prices for all eligible variants.
- `sentiment_vs_price.png`: PNG chart.
- `feature_matrix.csv`: per-session causal features.
- `audit_manifest.json`: input hashes, data cutoff, counts, sample limitations, strategy assumptions.
- `one_page_outlook.md`: short interpretation, explicitly synthetic or provenance-WITHHELD.

## Critical unfinished steps
1. **Actual 180-day X data**: choose a permitted Apify actor or provider, confirm actual JSON fields/rights, actor/dataset ID, pagination, missing/duplicate posts, timestamp precision and real window. Earlier optional connectors can be adapted by Codex after schema validation. Never fabricate actor IDs or public post text.
2. **Real price data**: ensure proper symbol, XNYS calendar, source rights, open/close consistency, split/dividend policy, raw price hashes and timely last close.
3. **Text validity**: lexical scoring cannot robustly distinguish sarcasm, repost quotes, and replies; compare to a permissioned classifier only after license and annotation checks. FinBERT ProsusAI model weights are **non-commercial CC BY-NC-SA 4.0**, not automatically free for commercial use.
4. **Current news**: Tavily/Exa through separate verified private connector; do not leak into model history. The starter's offline outlook includes no fetched news.
5. **True PIT influence**: unless historical engagement snapshots exist, the influence variant is withheld; no artificial celebrity boost from name recognition.
6. **Trading performance**: theoretical daily open and close fills, costs fixed at an uncalibrated round-trip 20 bps, no taxes/slippage/market impact verification; not deployable alpha.
7. **Formal source audit, independent tests, final report, GitHub publication and assessment submission** remain separate work.

## Audit material
Read `docs/DEEP_AUDIT_AND_DECISION.md`, `docs/FREE_MODEL_REVIEW_PROMPTS.md` and `docs/CODEX_FINAL_HANDOFF.md`. Use independent Grok and DeepSeek feedback as proposals, not source truth. Do not copy confidential ASTRA code into public submissions.

## Scope and source notes
The project currently chooses AAPL (US equity) rather than BTC-USD because stock prices and an exchange close are natural interpretations of the assignment. This choice is reversible by explicitly changing the verified exchange and calendar, not by altering a ticker string alone. Yahoo Finance documentation states its historical intraday intervals are limited to 60 days, so a 180-calendar-day `1h` plan is not reliable as-is.

References: https://ranaroussi.github.io/yfinance/reference/yfinance.price_history.html ; https://huggingface.co/ProsusAI/finbert ; https://github.com/ProsusAI/finBERT ; https://github.com/gerrymanoim/exchange_calendars .

## Responsible AI transparency
AI-assisted research code and accompanying method documents were produced and tested in an isolated development container. This is a prototype; independently inspect source and reports before representing it as applicant-authored work. No private tokens, secret keys, employer source data, or real market results are bundled.

## v0.2 data preparation extension (15 Nov 2026)

Added `python -m cwt_unified.ingest` for auditable Apify-export normalization, date filtering, SQLite persistence and matching CSV generation. It does not scrape X or trigger an Apify Actor; permissioned remote datasets can be read only with an existing authorized dataset ID and `APIFY_TOKEN` set locally. Run `pytest -q` and follow `DATA_SETUP_AND_TASKS.md`. Legacy predictive code is unchanged and must not be treated as empirically validated.
