# Two independent free-mode audits before Codex

Paste these **separately** into Grok and DeepSeek. Attach the code ZIP or paste relevant source files; do not ask either to overwrite the same branch. Both are adversarial reviewers, not voters. Require patches and test cases, not unverifiable statements.

## Grok: X-data, sentiment, market microstructure and point-in-time audit

> You are an independent adversarial reviewer of a research-only quantitative assessment. One US listed equity (AAPL/XNYS as current default), X-created posts + daily OHLC over exactly 180 calendar days, n+0 observed close, direct n+1..n+5 close forecasts, expanding-window Ridge model. There are no live trades. I will provide a ZIP of the current code and its DEEP_AUDIT_AND_DECISION document.
>
> Audit specifically: (1) true X post creation time vs retrieval and edit history; (2) lawful historical corpus quality & 180-day coverage; (3) duplicates/quotes/bots and ambiguous cashtags; (4) author followers and likes *as-of each historical prediction cutoff*; (5) whether an observed reply truly agrees/disagrees about the **target asset**, vs merely positive/negative language; (6) source rights/provider identifiers; (7) celebrity influence, logarithmic caps, comment-stance 0.6/0.4 blending and no engagement-leakage; (8) NYSE DST, early close and next-session fills; (9) mock adversarial records with expected outputs.
>
> Your deliverable: P0 defects with path/function/line and failing example, minimal patch diffs in Python, at least five deterministic pytest cases, source URLs for any external claims, and an explicit VERIFIED/DISPUTED/WITHHELD/REJECTED classification. If you cannot inspect the uploaded file or cannot verify a claim, say WITHHELD. Do not claim access to X data, paid API history or historical engagement snapshots unless you can demonstrate it. Do not fabricate backtest returns, API limits, licenses or actor schemas. No RL or deep model proposals before leakage-proof baseline.
>
> Do not change the assignment objective, ticker calendar, horizon definitions, privacy rules or data provenance model. Avoid adding any output using future X popularity or current news in past backtests.

## DeepSeek: code/static testing + competing design audit

> You are a skeptical staff quantitative engineer. Review every source file and test of the provided unified Python package. Also evaluate, *only where the full input code is attached*, any earlier AAPL hourly or BTC-USD daily prototypes. The exact submission objective is US-equity daily close forecasts h=1..5 (h=0 observed), 180 calendar days of legally acquired X posts and OHLC, same test origins for naive/price-only/sentiment Ridge, optional capped point-in-time influence, and realistic next-open diagnostic.
>
> Required work: (1) trace the exact datatypes and index alignment of session close timestamps; (2) attempt look-ahead attacks on features, fitted scalers, labels, engagement snapshots and replies; (3) inspect missing days, post deduplication, author cap, neutral/no-post handling and ticker filter; (4) adversarial test of numerical stability and denominator-zero cases; (5) trace the entry/exit rule independently of forecast target; (6) audit packaging, reproducibility, input contracts and environment-secret hygiene; (7) identify missing assessment items such as provider connectors and price adjustment policy.
>
> Produce: precise failing tests and patch-ready minimal diffs, ordered P0/P1/P2, explicit evidence status, and clear `DO_NOT_MERGE` risks. Do not rewrite the code into a new framework, add paid services, hardcode tokens or claim tests ran unless you truly executed them. Include your exact Python version, libraries and commands for executed tests. If no execution environment, label results STATIC REVIEW ONLY. Prefer evidence and deterministic logic over creativity.

## Reconciliation protocol

Compare both audits by **claim and reproducer**, not by vote. Accept a patch only if (a) it preserves the source requirements, (b) a test fails before and passes after, (c) it introduces no future data or incompatible license, and (d) either a second independent source or independent reasoning supports the repair. Preserve original proposals and modified diffs in separate files to enable review. The final merger decision belongs to Codex only after source audit.
