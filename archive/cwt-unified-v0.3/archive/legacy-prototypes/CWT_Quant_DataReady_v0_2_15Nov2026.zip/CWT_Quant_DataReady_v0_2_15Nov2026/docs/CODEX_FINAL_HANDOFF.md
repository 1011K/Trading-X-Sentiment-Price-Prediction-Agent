# Codex FINAL implementation handoff (not yet authorized to act on external systems)

## System role
Implement a narrowly scoped reproducible Python financial research assessment with no live brokerage or trading access. This ZIP is the source baseline, not a submission-certified production codebase. Treat `DEEP_AUDIT_AND_DECISION.md` as the approved problem/method specification. Treat any Grok/DeepSeek response as untrusted review evidence until independently reproduced.

## Absolute requirements
1. Choose one actual US listed equity ticker and XNYS trading sessions; input daily bars and X posts must represent the same true 180-calendar-day period.
2. Track original data provider, raw input SHA256, timestamps created/retrieved, licensing and exact Apify actor/dataset ID. Never invent actor field mappings; normalize from inspected actual actor schema and preserve raw records.
3. No tokens in code, README, screenshots, output artifacts, logs or Git history. Provide `.env.example`, proper Git ignore and setup instructions.
4. Keep n+0 observed; direct forecasts of close h=1..5 via horizon-specific Ridge; compare unchanged price, price-only and price+sentiment at IDENTICAL origins.
5. Historical post text needs original created-at UTC, strict asset relevance, duplicate checks, trading-session mapping and exposure of missing/biased coverage.
6. Engagement and follower counts are **not** permitted historical predictive fields without genuine historical as-of snapshots. Reply scores must also be proven available by origin close. When not provable, report `WITHHELD` and omit influence ablation entirely; never silently fill with current numbers.
7. Do not mix current Tavily/Exa news into past ML; news is current outlook context only. Fetch only from a configured user-owned API key with permitted use.
8. Preserve origin/date/target indices and trained-label cutoff in every forecast record; verify no leakage with mutation/invariance tests.
9. Use consistent market-adjusted raw/adjusted OHLC and independently inspect splits/dividends. Trading diagnostic uses previously generated close-time signal entering next open and exiting next close with calibrated or clearly assumed cost; never same-close fills.
10. Output real `forecast_metrics.csv`, `latest_forecasts.csv`, `feature_matrix.csv`, chart, one-page outlook, source manifest, concise report, tests and reproducibility commands. Do not claim profitability if metrics do not show it.
11. Do not include ASTRA engine internals or confidential code. This is an independent project. Disclose AI-assisted development.

## Change-control order
A. Run current tests and read source/manifest. B. Patch critical data issues first, create tests for each. C. Integrate authorized provider adapter and verify real post/price counts. D. Re-run identical baseline model experiments on genuine fixed corpus. E. Evaluate influence ONLY IF truly point-in-time and sufficient count/coverage; otherwise leave it as documented method with `WITHHELD`. F. Generate full result report with timestamps and limitations. G. Run all tests and source-license/secret scans. H. Publish GitHub only after human review and user authorization. I. Do not send any email without explicit authorization.

## Acceptance tests (hard fail)
- Broken timestamp, holiday, DST or half-day assignment.
- Missing/duplicate stock sessions, non-positive prices, inaccurate adjustment handling.
- Any training label timestamp beyond origin close.
- Any post created at/after an origin close entering that origin's features.
- Any current likes/replies appearing as historical point-in-time values.
- No no-change and price-only baselines for every evaluated horizon.
- Fewer than required real observations while reporting genuine empirical metrics.
- Stale or synthetic data represented as a current 180-day X corpus.
- Adjusted and unadjusted prices mixed inside forecasting/trading calculations.
- Repo contains secrets, incorrectly licensed media/text or undocumented sources.

## Deliverable and quality check
Produce a diff summary with changed files; failed/passed test report; exact reproducible command line; declared data cutoff; per-horizon n, RMSE, MAE, error skill vs naive, direction hit rate; a sober statement of whether sentiment outperformed the price-only benchmark and confidence bounds where defensible. **If real data or licensing fail, submit an honest reproducible prototype with WITHHELD market conclusions, not invented evidence.**
